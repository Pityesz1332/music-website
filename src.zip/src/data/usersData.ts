export type User = {
    id: number;
    name: string;
    email: string;
    role: "user" | "admin";
};

export const usersData: User[] = [
    { id: 1, name: "Admin", email: "admin@site.com", role: "admin" },
    { id: 2, name: "Nova", email: "nova@example.com", role: "user" },
    { id: 3, name: "Echo", email: "echo@example.com", role: "user" },
    { id: 4, name: "Luna", email: "luna@example.com", role: "user" },
    { id: 5, name: "Pulse", email: "pulse@example.com", role: "user" }
];